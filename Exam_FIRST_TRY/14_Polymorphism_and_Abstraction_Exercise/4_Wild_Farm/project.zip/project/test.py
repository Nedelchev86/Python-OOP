from project.animals.birds import Hen
from project.animals.mammals import Tiger
from project.food import Vegetable, Fruit, Meat

hen = Hen("Harry", 10, 10)
veg = Vegetable(3)
fruit = Fruit(5)
meat = Meat(1)
print(hen)
print(hen.make_sound())
hen.feed(veg)
hen.feed(fruit)
hen.feed(meat)
print(hen)

tiger = Tiger("Ivan", 20, 14)
print(tiger)
