from project.dark_wizard import DarkWizard


class SoulMaster(DarkWizard):
    pass
