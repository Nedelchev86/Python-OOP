from project.car import Car


class FamilyCar(Car):
    pass
