from project.reptile import Reptile


class Snake(Reptile):
    pass