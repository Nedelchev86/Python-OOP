from project.mammal import Mammal


class Bear(Mammal):
    def __init(self, name):
        super().__init__(name)